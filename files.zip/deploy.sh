#!/usr/bin/env bash
set -euo pipefail

# ============================================================
#  deploy.sh — Pull and run on a Linux server
#  Usage:
#    ./deploy.sh docker    # Run with Docker Compose
#    ./deploy.sh k8s       # Deploy to Kubernetes
#    ./deploy.sh bare      # Run Go binary directly
#
#  Environment variables (set before running):
#    JWT_SECRET  — signing key for JWT tokens (required in prod)
#    API_USER    — login username (default: demo)
#    API_PASS    — login password (default: demo)
# ============================================================

MODE="${1:-docker}"
IMAGE_NAME="crypto-dashboard"
IMAGE_TAG="latest"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Deploying crypto-dashboard ($MODE)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

case "$MODE" in

docker)
  echo "→ Building Docker image..."
  docker build -t "$IMAGE_NAME:$IMAGE_TAG" .

  echo "→ Stopping old container (if any)..."
  docker rm -f crypto-dashboard 2>/dev/null || true

  echo "→ Starting container..."
  docker run -d \
    --name crypto-dashboard \
    --restart unless-stopped \
    -p 8080:8080 \
    --memory=128m \
    --cpus=0.5 \
    -e PORT=8080 \
    -e JWT_SECRET="${JWT_SECRET:-dev-secret-change-in-production}" \
    -e API_USER="${API_USER:-demo}" \
    -e API_PASS="${API_PASS:-demo}" \
    "$IMAGE_NAME:$IMAGE_TAG"

  echo ""
  echo "✅ Running at http://localhost:8080"
  echo "   Login: ${API_USER:-demo} / ${API_PASS:-demo}"
  echo "   Logs: docker logs -f crypto-dashboard"
  ;;

k8s)
  echo "→ Building Docker image..."
  docker build -t "$IMAGE_NAME:$IMAGE_TAG" .

  echo "→ Applying Kubernetes manifests..."
  kubectl apply -f namespace.yaml
  kubectl apply -f secret.yaml
  kubectl apply -f deployment.yaml
  kubectl apply -f service.yaml
  kubectl apply -f hpa.yaml

  echo "→ Waiting for rollout..."
  kubectl rollout status deployment/crypto-dashboard -n crypto-dashboard --timeout=120s

  echo ""
  echo "✅ Deployed to Kubernetes"
  echo "   ⚠️  Edit secret.yaml with real credentials first!"
  echo "   kubectl get pods -n crypto-dashboard"
  echo "   kubectl port-forward -n crypto-dashboard svc/crypto-dashboard 8080:80"
  ;;

bare)
  echo "→ Building Go binary..."
  go build -o aggregator .

  echo "→ Starting server..."
  exec ./aggregator
  ;;

*)
  echo "Usage: $0 {docker|k8s|bare}"
  exit 1
  ;;

esac
